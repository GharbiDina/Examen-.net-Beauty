﻿namespace ApplicationCore
{
    public class Class1
    {

    }
}
